App.BillAmount = DS.Model.extend({
	billAmount: DS.attr('string')
});